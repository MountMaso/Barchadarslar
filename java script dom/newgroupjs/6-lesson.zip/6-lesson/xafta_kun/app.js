const dayOfNumber=prompt('Ixtiyoriy son kiriting');

if(dayOfNumber=='1'){
    console.log('Bugun Dushanba kuni');
}
else if(dayOfNumber=='2'){
    console.log('Bugun Seshanba kuni');
}
else if(dayOfNumber=='3'){
    console.log('Bugun Chorshanba kuni');
}
else if(dayOfNumber=='4'){
    console.log('Bugun Payshanba kuni');
}
else if(dayOfNumber=='5'){
    console.log('Bugun Juma kuni');
}
else if(dayOfNumber=='6'){
    console.log('Bugun Shanba kuni');
}
else if(dayOfNumber=='7'){
    console.log('Bugun Yakshanba kuni');
}
else{
    console.log('Bunday hafta kuni mavjud emas...');
}